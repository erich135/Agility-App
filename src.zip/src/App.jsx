import React, { useEffect, useState } from "react";
import { supabase } from "./lib/supabaseClient";
import { getDueStatus } from "./lib/dueStatus";
import dayjs from "dayjs";

function App() {
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState("client_name");
  const [sortAsc, setSortAsc] = useState(true);

  useEffect(() => {
    fetchClients();
  }, [sortBy, sortAsc]);

  const fetchClients = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("clients")
      .select("*")
      .order(sortBy, { ascending: sortAsc });

    if (error) {
      console.error("Error fetching data:", error.message);
    } else {
      setClients(data);
    }
    setLoading(false);
  };

  const updateFiling = async (id, type = "cipc", action = "mark") => {
    const confirm = window.confirm(
      `${action === "mark" ? "Mark" : "Undo"} ${type.toUpperCase()} filing?`
    );
    if (!confirm) return;

    const updateData = {
      [`last_${type}_filed`]: action === "mark" ? dayjs().format("YYYY-MM-DD") : null,
      updated_at: new Date().toISOString(),
    };

    const { error } = await supabase.from("clients").update(updateData).eq("id", id);

    if (error) {
      alert("Error updating: " + error.message);
    } else {
      await fetchClients(); // ✅ Refresh local state
    }
  };

  const deleteClient = async (id) => {
    const confirm = window.confirm("Are you sure you want to delete this client?");
    if (!confirm) return;
    const { error } = await supabase.from("clients").delete().eq("id", id);
    if (error) {
      alert("Delete failed: " + error.message);
    } else {
      fetchClients();
    }
  };

  const getRowColor = (client) => {
  const today = new Date();

  const cipcFiledDate = client.cipc_filed ? new Date(client.cipc_filed) : null;
  const boFiledDate = client.bo_filed ? new Date(client.bo_filed) : null;

  // If both filed and in future => green
  if (cipcFiledDate && boFiledDate && cipcFiledDate >= today && boFiledDate >= today) {
    return '#00FF00'; // Green
  }

  // If either is missing or overdue => red
  if (!cipcFiledDate || cipcFiledDate < today || !boFiledDate || boFiledDate < today) {
    return '#FF0000'; // Red
  }

  // Fallback (shouldn't happen)
  return '#FFA500'; // Orange
};

  const handleSort = (field) => {
    if (sortBy === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortBy(field);
      setSortAsc(true);
    }
  };

  const filteredClients = clients.filter((client) =>
    client.client_name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-6 max-w-screen-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">CIPC Annual Returns Tracker</h1>

      <div className="mb-4">
        <input
          type="text"
          placeholder="Search clients..."
          className="border border-gray-300 rounded px-3 py-2 w-full max-w-md"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {loading ? (
        <p>Loading clients...</p>
      ) : (
        <div className="overflow-x-auto shadow rounded">
          <table className="min-w-full bg-white border">
            <thead className="bg-gray-200">
              <tr>
                <th className="p-2 text-left cursor-pointer" onClick={() => handleSort("client_name")}>
                  Client Name {sortBy === "client_name" && (sortAsc ? "▲" : "▼")}
                </th>
                <th className="p-2 text-left">Reg Number</th>
                <th className="p-2 text-left">Reg Date</th>
                <th className="p-2 text-left">Due Month</th>
                <th className="p-2 text-left">CIPC Filed</th>
                <th className="p-2 text-left">BO Filed</th>
                <th className="p-2 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredClients.map((client) => (
                <tr key={client.id} className={getRowColor(client)}>
                  <td className="p-2">{client.client_name}</td>
                  <td className="p-2">{client.registration_number}</td>
                  <td className="p-2">
                    {new Date(client.registration_date).toLocaleDateString()}
                  </td>
                  <td className="p-2">
                    {new Date(client.registration_date).toLocaleString("default", {
                      month: "long",
                    })}
                  </td>
                  <td className="p-2">
                    {client.last_cipc_filed
                      ? new Date(client.last_cipc_filed).toLocaleDateString()
                      : "-"}
                  </td>
                  <td className="p-2">
                    {client.last_bo_filed
                      ? new Date(client.last_bo_filed).toLocaleDateString()
                      : "-"}
                  </td>
                  <td className="p-2 space-y-1 space-x-1">
                    <div>
                      <button
                        onClick={() => updateFiling(client.id, "cipc", "mark")}
                        className="px-2 py-1 bg-blue-500 text-white rounded hover:bg-blue-600"
                      >
                        Mark CIPC
                      </button>
                      {client.last_cipc_filed && (
                        <button
                          onClick={() => updateFiling(client.id, "cipc", "undo")}
                          className="px-2 py-1 bg-gray-400 text-white rounded hover:bg-gray-500 ml-2"
                        >
                          Undo
                        </button>
                      )}
                    </div>
                    <div>
                      <button
                        onClick={() => updateFiling(client.id, "bo", "mark")}
                        className="px-2 py-1 bg-purple-500 text-white rounded hover:bg-purple-600"
                      >
                        Mark BO
                      </button>
                      {client.last_bo_filed && (
                        <button
                          onClick={() => updateFiling(client.id, "bo", "undo")}
                          className="px-2 py-1 bg-gray-400 text-white rounded hover:bg-gray-500 ml-2"
                        >
                          Undo
                        </button>
                      )}
                    </div>
                    <div>
                      <button
                        onClick={() => deleteClient(client.id)}
                        className="px-2 py-1 bg-red-600 text-white rounded hover:bg-red-700 mt-2"
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {filteredClients.length === 0 && (
            <p className="p-4 text-center text-gray-500">No clients found.</p>
          )}
        </div>
      )}
    </div>
  );
}

export default App;
